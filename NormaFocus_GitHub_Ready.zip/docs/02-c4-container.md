# Артефакт 2. C4 — уровень Container

**Система:** NormaFocus. **Уровень C4:** Container (контейнер = отдельно развёртываемое приложение или хранилище, не обязательно Docker-контейнер). **Статус:** проектируемая архитектура.

## 1. Контейнерная диаграмма (Mermaid C4Container)

```mermaid
C4Container
    title NormaFocus — целевая микросервисная архитектура (Container)

    Person(user, "Пользователь", "B2C или сотрудник организации")
    System_Ext(llm, "Локальная T-Lite", "llama.cpp / HTTP API; доступность не гарантирована")

    System_Boundary(nf, "NormaFocus (целевая система)") {
        Container(ui, "Веб-клиент", "Web UI", "Загрузка документов, статусы и вопросы")
        Container(gw, "API Gateway", "Reverse proxy / Auth", "Маршрутизация, JWT, лимиты")
        Container(cat, "Document Catalog", "Python / FastAPI", "Оригиналы, версии, публикация")
        Container(wf, "Publication Workflow", "Python / worker + HTTP", "Оркестратор Saga, повторы")
        Container(ext, "Extraction", "Python / worker", "Извлечение PDF/DOCX/TXT")
        Container(idx, "Search Index", "Python / FastAPI + worker", "Фрагменты, полнотекстовый поиск")
        Container(ans, "Answer", "Python / FastAPI", "RAG, цитаты, запросы к T-Lite")
        ContainerDb(catdb, "Catalog DB", "PostgreSQL", "Версии, idempotency, outbox")
        ContainerDb(wfdb, "Workflow DB", "PostgreSQL", "Saga, inbox, outbox, таймеры")
        ContainerDb(extdb, "Extraction DB", "PostgreSQL", "Задания, inbox, outbox")
        ContainerDb(idxdb, "Index DB", "PostgreSQL FTS", "Чанки, видимость, inbox, outbox")
        ContainerDb(source, "Original Files", "S3-compatible", "Неизменяемые исходники; зона Catalog")
        ContainerDb(extracted, "Text Artifacts", "S3-compatible", "Извлечённый текст; зона Extraction")
        Container(broker, "RabbitMQ", "AMQP 0-9-1", "Долговечные команды и события")
    }

    Rel(user, ui, "Использует", "HTTPS")
    Rel(ui, gw, "API", "HTTPS / JSON, multipart")
    Rel(gw, cat, "Регистрация и статусы", "HTTP")
    Rel(gw, wf, "Статус операции", "HTTP")
    Rel(gw, ans, "Вопросы", "HTTP")
    Rel(cat, catdb, "Чтение/запись, outbox", "SQL")
    Rel(cat, source, "Сохранение и доступ к оригиналу", "S3 API")
    Rel(cat, broker, "События registered/published", "AMQP")
    Rel(wf, wfdb, "Saga, inbox/outbox", "SQL")
    Rel(wf, broker, "Команды и результаты", "AMQP")
    Rel(wf, cat, "Begin, publish, fail", "HTTP + service JWT")
    Rel(ext, extdb, "Задания, inbox/outbox", "SQL")
    Rel(ext, source, "Читает выданный объект", "Ограниченная ссылка S3")
    Rel(ext, extracted, "Сохраняет извлечённый текст", "S3 API")
    Rel(ext, broker, "Команды, результаты", "AMQP")
    Rel(idx, idxdb, "Индекс и маркеры", "SQL")
    Rel(idx, extracted, "Читает проверенный текст", "Ограниченная ссылка S3")
    Rel(idx, broker, "Команды, результаты, публикация", "AMQP")
    Rel(ans, idx, "Ищет чанки", "HTTP + service JWT")
    Rel(ans, cat, "Проверяет текущие версии", "HTTP + service JWT")
    Rel(ans, llm, "Генерация ответа", "HTTP / OpenAI-compatible")
```

> `ContainerDb` указывает **логическое владение БД**, а не обязательно разные физические серверы PostgreSQL. На учебном стенде они могут работать на одном хосте, но с разными базами и учётными записями; прямые кросс-сервисные SQL-запросы запрещены. Для объёмной диаграммы это намеренно один C4-Container view, а не схема физической сети.

## 2. Синхронные и асинхронные границы

| Связь | Механизм | Что происходит при недоступности |
|---|---|---|
| Веб-клиент → Catalog | HTTP (multipart + idempotency key) | До подтверждения можно повторить тем же ключом; 202 означает запись и outbox уже зафиксированы |
| Catalog → Workflow | RabbitMQ, `revision.registered.v1` | Событие остаётся в Catalog outbox и повторно публикуется |
| Workflow → Extraction/Index | RabbitMQ, долговечные команды | Команды хранятся в outbox Workflow, подтверждаются только после фиксации результата потребителем |
| Extraction/Index → Workflow | RabbitMQ, события | Inbox предотвращает повторное применение; таймаут проверяет состояние перед повтором |
| Workflow → Catalog | HTTP сервис-сервис: start/publish/fail | Повтор с тем же `workflow_id` и `attempt`, compare-and-set; без двойной публикации |
| Catalog → Index | RabbitMQ, `revision.published.v1` | Пока событие не дошло, новая версия может не попасть в поиск; неопубликованные данные не видны |
| Answer → Index → Catalog | HTTP | При недоступности Catalog ответ не формируется на непроверенных редакциях (fail closed) |
| Answer → T-Lite | HTTP | Ошибка 503 без изменения оригиналов и публикаций |

## 3. Развёртывание и логическая безопасность

**Целевая учебная среда:** Docker Compose (не считать существующим файлом проекта), Python/FastAPI, PostgreSQL (четыре логические БД), RabbitMQ с durable quorum queues и DLQ, S3-совместимое объектное хранилище; индекс — PostgreSQL FTS для достижимого учебного MVP. Модель T-Lite рассматривается как внешний локальный сервис с адаптером, чтобы не переносить её тяжёлую инференс-нагрузку в Catalog.

**Точки доступа:** снаружи доступны только Web UI и API Gateway. Маршруты `/internal/*`, RabbitMQ, PostgreSQL и S3 не публикуются в интернет. Пользовательские токены подтверждают `tenant_id`, роль и доступ к документу, а сервисные токены — идентичность и разрешённые действия приложения. При Business/B2B изоляция должна быть проверяема по каждому запросу и событию. Самовольное обращение к исторической production SQLite и изменения доменов NormaFocus недопустимы.

**Отказы:** у каждого сервиса собственный health/readiness endpoint; liveness не означает доступность брокера или модели. Для сообщений используется подтверждение потребления после транзакции, DLQ для необрабатываемых событий, outbox relay с ретраями, а для данных — резервное копирование и проверка восстановления. Временные значения 3 попытки, 60 секунд ожидания шагов и интервал повторов — **проектные параметры для стенда**, а не измеренные SLO.

## 4. Почему это микросервисы, а не пять классов одного приложения

Каждый из Catalog, Workflow, Extraction и Search Index обладает **собственным состоянием, правом записи, схемой данных и жизненным циклом**. Публикация проходит через независимые фиксируемые транзакции и компенсирующие сообщения; единый `BEGIN/COMMIT` недоступен. Answer отделён из-за нестабильности/нагрузки локальной модели и требований к фильтрации источников. Однопроцессный монолит с одной БД технически возможен для упрощённого MVP, но **не выполняет поставленную для задания модель независимых хранилищ, асинхронных этапов и изоляции отказов**; поэтому выбранный сценарий специально проектируется с межсервисной согласованностью.
