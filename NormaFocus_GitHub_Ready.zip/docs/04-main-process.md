# Артефакт 4. Основной процесс и сценарии отказов

**Процесс:** регистрация и публикация новой редакции нормативного документа. Ниже одна успешная Sequence-диаграмма и **ровно три обязательные диаграммы отказа**, в каждом случае указано, что ломается и как выполняется восстановление/компенсация. Это алгоритм проектируемой Saga; диаграммы не утверждают, что он уже запущен.

## 1. Состояния и предпосылки

- `REGISTERED` — оригинал загружен, проверен по checksum, метаданные и outbox записаны в Catalog; пользователь получил `202`.
- `PROCESSING` — Workflow получил управление попыткой `attempt ∈ {1,2,3}`, Catalog подтвердил начало обработки.
- `PUBLISHED` — единственная текущая версия документа изменена в Catalog, событие публикации находится в outbox. Отставание обновления поисковой проекции допустимо.
- `FAILED` — исчерпаны попытки или возникла постоянная ошибка; оригинал и метаданные сохранены; фрагменты неудачной попытки удалены/изолированы.

События `extraction.completed` и `indexing.completed` принимаются только если совпадают `(tenant_id, revision_id, attempt)` текущей Saga. Индекс строится **в staging** и не виден ответам до `revision.published`. Workflow берёт одно исполнение по `workflow_id` под блокировку БД; все входящие события сохраняет через inbox. Повторы происходят после таймаута или ошибки, с backoff; для каждой новой попытки `attempt` увеличивается.

### Успешный сценарий

```mermaid
sequenceDiagram
    autonumber
    actor User as Пользователь
    participant Cat as Document Catalog
    participant CDB as Catalog DB + outbox
    participant MQ as RabbitMQ
    participant WF as Workflow
    participant Ext as Extraction
    participant Idx as Search Index
    participant Ans as Answer

    User->>Cat: POST /documents/{id}/revisions (file, Idempotency-Key)
    Cat->>Cat: SHA-256 и PUT оригинала в S3
    Cat->>CDB: TX: INSERT revision REGISTERED + idem + outbox
    CDB-->>Cat: COMMIT
    Cat-->>User: 202 revision_id, state=REGISTERED
    Cat->>MQ: revision.registered.v1 (outbox relay)
    MQ-->>WF: доставить registered
    WF->>WF: inbox + открыть Saga attempt=1
    WF->>Cat: POST /internal/revisions/{id}/processing (attempt=1)
    Cat-->>WF: PROCESSING
    WF->>MQ: extraction.requested.v1 (outbox)
    MQ-->>Ext: обработать ревизию 1
    Ext->>Cat: GET /internal/revisions/{id}/source-url
    Cat-->>Ext: временная ссылка на оригинал
    Ext->>Ext: извлечь текст, сохранить артефакт + checksum
    Ext->>MQ: extraction.completed.v1 (outbox)
    MQ-->>WF: результат извлечения
    WF->>MQ: indexing.requested.v1
    MQ-->>Idx: сформировать staging-индекс
    Idx->>Idx: TX: чанки + READY + outbox
    Idx->>MQ: indexing.completed.v1 (outbox)
    MQ-->>WF: индекс READY for attempt=1
    WF->>Cat: POST /internal/revisions/{id}/publish (attempt=1)
    Cat->>CDB: TX: CAS PROCESSING→PUBLISHED, current_revision_id, outbox
    CDB-->>Cat: COMMIT
    Cat-->>WF: 200 PUBLISHED
    Cat->>MQ: revision.published.v1 (outbox relay)
    MQ-->>Idx: разрешить чтение staging attempt=1
    Idx->>Idx: TX: visible=true, inbox
    WF->>WF: DONE (после подтверждения publish)
    User->>Ans: POST /v1/answers (вопрос)
    Ans->>Idx: POST /internal/search
    Idx-->>Ans: только visible фрагменты tenant
    Ans->>Cat: POST /internal/revisions/check-current
    Cat-->>Ans: актуальные revision_id
    Ans->>Ans: отбросить устаревшие и сформировать контекст
    Ans-->>User: ответ с цитатами (LLM вызов показан на C4)
```

В этой диаграмме успешный ответ Answer означает, что модель доступна; её вызов вынесен из Sequence ради читаемости. **Гарантия:** подтверждение регистрации не зависит от скорости Extraction, Index или локальной LLM. **Временное ограничение:** после `PUBLISHED` индекс может быть ещё не виден из-за задержки события; это не разрешает отдавать устаревшую редакцию (Catalog проверяет `current_revision_id` на этапе вопроса).

### Отказ №1. RabbitMQ недоступен после коммита Catalog

```mermaid
sequenceDiagram
    autonumber
    actor U as Пользователь
    participant Cat as Catalog
    participant DB as Catalog DB / outbox
    participant Relay as Outbox relay
    participant MQ as RabbitMQ
    participant WF as Workflow

    U->>Cat: Загрузить новую редакцию с Idempotency-Key
    Cat->>DB: TX: ревизия REGISTERED + outbox
    DB-->>Cat: COMMIT
    Cat-->>U: 202; revision_id сохранён
    Relay->>DB: SELECT необработанных outbox
    Relay-xMQ: publish revision.registered (брокер недоступен)
    Note over Relay,DB: Outbox НЕ удаляется, запись остаётся durable
    U->>Cat: GET /v1/revisions/{id}
    Cat-->>U: REGISTERED, публикация ожидается
    loop retry с backoff после восстановления RabbitMQ
        Relay->>MQ: publish + publisher confirm
    end
    MQ-->>WF: registered (at-least-once)
    WF->>WF: уникальный inbox + один workflow_id
    WF-->>MQ: ACK после commit
    Note over Cat,WF: Продолжить извлечение/индексацию; двойной Saga не возникает
```

**Что сломалось:** доставка события из Catalog. **Компенсация/восстановление:** удалять документ нельзя; outbox relay повторяет публикацию до подтверждения, Workflow дедуплицирует. При длительном простое мониторинг создаёт сигнал `outbox_lag`; документ остаётся в `REGISTERED`, пользователь видит ожидание. Двойной бизнес-операции нет даже если брокер принял сообщение, но подтверждение публикации потерялось.

### Отказ №2. Index Service падает во время построения индекса

```mermaid
sequenceDiagram
    autonumber
    participant WF as Workflow
    participant MQ as RabbitMQ
    participant Idx as Search Index
    participant IDB as Index DB
    participant Cat as Catalog

    WF->>MQ: indexing.requested (attempt=1)
    MQ-->>Idx: доставка команды
    Idx->>IDB: BEGIN; INSERT часть фрагментов
    Idx-xIDB: падение процесса до COMMIT
    Note over IDB: Откат транзакции, READY не записан
    Note over MQ,Idx: Нет ACK; повторная доставка возможна
    MQ-->>Idx: повтор indexing.requested (attempt=1)
    Idx-xIdx: повтор снова не завершился / timeout
    WF->>MQ: indexing.discard.requested (attempt=1)
    MQ-->>Idx: discard (attempt=1)
    Idx->>IDB: TX: tombstone attempt=1 + DELETE staged rows
    IDB-->>Idx: COMMIT
    Idx->>MQ: indexing.discarded.v1
    MQ-->>WF: компенсация подтверждена
    WF->>Cat: processing (attempt=2, CAS)
    Cat-->>WF: PROCESSING, current_attempt=2
    WF->>MQ: extraction.requested (attempt=2)
    Note over WF,Idx: Если после 3 попыток нет успеха: discard, затем Catalog FAILED
```

**Что сломалось:** Index не завершил локальную транзакцию. **Компенсация:** отменить и очистить **staging только попытки 1**; сохранить tombstone от поздней доставки; подтвердить очистку и только после этого перейти к попытке 2. Если в одной из следующих попыток уже создан успешный индекс, он публикуется отдельно. При исчерпании трёх попыток Workflow вызывает `fail`, Catalog оставляет оригинал в `FAILED`, а **ни один из неготовых индексов не становится видимым**. Если Index всё ещё недоступен, Saga остаётся в `COMPENSATING`, а не ложно переходит в `FAILED`: очистка догонит при восстановлении.

### Отказ №3. Catalog фиксирует публикацию, но ответ Workflow теряется

```mermaid
sequenceDiagram
    autonumber
    participant WF as Workflow
    participant Cat as Catalog
    participant DB as Catalog DB / outbox
    participant MQ as RabbitMQ
    participant Idx as Search Index

    Note over WF,Cat: Index уже подтвердил READY (attempt=1)
    WF->>Cat: POST /internal/revisions/{id}/publish (attempt=1)
    Cat->>DB: TX: CAS PUBLISHED + current_revision_id + outbox
    DB-->>Cat: COMMIT
    Cat-xWF: сеть оборвалась: HTTP 200 потерян
    WF->>WF: Не считать операцию неуспешной наугад
    WF->>Cat: повторить publish (тот же workflow_id, attempt)
    Cat->>DB: Найти уже зафиксированную публикацию
    DB-->>Cat: PUBLISHED, ключ совпадает
    Cat-->>WF: 200 PUBLISHED (без второй записи/события)
    WF->>WF: DONE
    Cat->>MQ: revision.published (исходный outbox)
    MQ-->>Idx: публикация attempt=1
    Idx->>Idx: inbox + visible=true (идемпотентно)
    Note over WF,Idx: Один эффект публикации; повтор доставки безопасен
```

**Что сломалось:** HTTP-ответ/соединение уже **после** коммита. **Компенсация/восстановление:** здесь нельзя «откатить публикацию» из-за пропавшего ответа; сначала читается существующее состояние, а идемпотентный повтор возвращает подтверждение той же публикации. Catalog фиксирует `current_revision_id` и outbox атомарно. Отправка `revision.published` может повториться, Search Index использует inbox и уникальность `(revision_id, attempt)`.

## 2. Что при других сбоях (для вопросов преподавателя)

| Что упало | Реакция системы |
|---|---|
| Extraction после сохранения текста, до события | Объект и запись задания остаются; outbox с результатом догоняет. Команда с тем же ключом не создаёт второй артефакт. |
| Workflow между двумя шагами | После рестарта читает свою БД, inbox/outbox и таймер; возобновляет текущую попытку. Другой экземпляр не исполняет тот же `workflow_id` одновременно. |
| Index готов, а Catalog недоступен | Публикация повторяется; staging не виден, оригинал сохранён, Workflow не отмечает DONE. |
| Ответ модели T-Lite не получен | Answer возвращает `503`, но не меняет статус редакции и не расходует новую публикацию. |
| Событие пришло дважды или поздно | `inbox(event_id)` и `(revision_id, attempt)` дают один эффект; устаревшая попытка отсекается CAS/tombstone. |
| Отказ сервиса Catalog | Не принимаются новые публикации и не выдаются ответы на основе непроверенной актуальности; после возврата Catalog операции возобновляются по журналам. |
| Потеря объекта в S3 | Индекс не считается доказательством сохранности оригинала. Срабатывает контроль целостности/алерт; восстановление из резервной копии или реплики. Без бэкапов нулевую потерю обещать нельзя. |
| Подвисла компенсация | Saga остаётся `COMPENSATING` и фиксируется как инцидент, пока не поступит `indexing.discarded`; ручной re-drive должен быть идемпотентен. |

## 3. Машина состояний Saga (внутренняя, отдельно от статуса Catalog)

```mermaid
stateDiagram-v2
    [*] --> WAIT_EXTRACT: registered / processing accepted
    WAIT_EXTRACT --> WAIT_INDEX: extraction.completed
    WAIT_INDEX --> PUBLISHING: indexing.completed
    PUBLISHING --> DONE: Catalog PUBLISHED
    WAIT_EXTRACT --> COMPENSATING: fail/timeout
    WAIT_INDEX --> COMPENSATING: fail/timeout
    COMPENSATING --> WAIT_EXTRACT: discarded + attempts remain
    COMPENSATING --> TERMINAL_FAILURE: discarded + attempt = 3
    TERMINAL_FAILURE --> FAILED: Catalog FAILED
    PUBLISHING --> PUBLISHING: lost HTTP reply / retry
    DONE --> [*]
    FAILED --> [*]
```

Для случаев **детерминированной ошибки** (например, зашифрованный/неподдерживаемый документ) допускается сразу перейти к компенсации и `FAILED` без повторной обработки. Количество попыток и продолжительность дедлайнов задаются политикой, а не свойствами брокера.

## 4. Инварианты для доказательства корректности

1. **Safety:** `Catalog.PUBLISHED` для `revision_id` существует максимум один раз, а `current_revision_id` обновляется транзакционно; нет публикуемой ревизии без подготовленного READY для активной попытки.
2. **No leaks:** `tenant_id` проверяется на каждом пересечении границы; при поиске старые/непроверенные версии удаляются из результатов до вызова ИИ.
3. **No ghost index:** `COMPENSATING` формирует tombstone; на `discard` удаляются staged-чанки, поздние команды для отменённой попытки не восстанавливают индекс.
4. **Progress при восстановленных зависимостях:** outbox relay и потребители повторяют операции; зависшие Saga восстанавливаются по дедлайнам. Если все внешние зависимости навсегда недоступны, гарантировать завершение нельзя.
5. **Durability:** зарегистрированный оригинал не участвует в компенсации, но для реальной защиты от физической потери данных необходимы проверенные резервные копии каталога, журналов и объектного хранилища.
